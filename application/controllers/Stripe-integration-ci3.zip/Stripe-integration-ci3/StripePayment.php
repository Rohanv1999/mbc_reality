<?php

use \Stripe\Checkout\Session;
use \Stripe\Stripe;

class StripePayment extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

    }
    public function index()
    {
        // form view here 
        $this->load->view('front_end/payment_check');
    }

    public function create()
    {
        $amount = $this->input->post('amount');
        $qty = 4;
        Stripe::setApiKey($this->config->item('stripe_secret_key'));
        $checkout_session = Session::create([
            "line_items" => [
                [
                    "price_data" => [
                        "currency" => "inr",
                        "product_data" => [
                            "name" => "Purchase Item: fd",
                            "description" => "this ",
                        ],
                        "unit_amount" => $amount * 100
                    ],
                    "quantity" => 1
                ]
            ],
            'payment_method_types' => [
                'card'
            ],
            'mode' => 'payment',
            'success_url' => base_url('StripePayment/success'),
            'cancel_url' => base_url('StripePayment/cancel'),
        ]);
        header('Location: ' . $checkout_session->url);


    }

    public function success()
    {
       
        echo 'success'; // success view
    }

    public function cancel()
    {
        
        echo 'cancel'; // cancel view
    }



}